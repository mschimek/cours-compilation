#ifndef __AFFICHE_ARBRE_ABSTRAIT__
#define __AFFICHE_ARBRE_ABSTRAIT__

#include "syntabs.h"

void construire_n_prog(n_prog *n);

#endif

